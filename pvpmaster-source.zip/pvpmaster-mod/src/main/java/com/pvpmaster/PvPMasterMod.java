package com.pvpmaster;

import com.pvpmaster.features.*;
import com.pvpmaster.fps.FpsBoostManager;
import com.pvpmaster.hud.PvPHudRenderer;
import com.pvpmaster.util.SessionStats;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * ╔══════════════════════════════════════════════════════════╗
 * ║           PvPMaster v3.0.0                              ║
 * ║     Ultimate Fabric PvP Mod - Minecraft 1.21.1           ║
 * ║                                                          ║
 * ║  90 FEATURES:                                            ║
 * ║  • 18 HUD Features      • 22 PvP/Combat Features         ║
 * ║  • 15 FPS Boost         • 20 Visual Features             ║
 * ║  • 15 Utility Features                                   ║
 * ║                                                          ║
 * ║  Keybindings:                                            ║
 * ║  RIGHT SHIFT → Settings GUI                              ║
 * ║  C           → Zoom                                      ║
 * ║  V           → Toggle Sprint                             ║
 * ║  X           → Toggle Sneak                              ║
 * ║  B           → Toggle Hitboxes                           ║
 * ║  N           → Toggle Fullbright                         ║
 * ║  M           → Session Stats                             ║
 * ╚══════════════════════════════════════════════════════════╝
 */
public class PvPMasterMod implements ClientModInitializer {

    public static final String MOD_ID = "pvpmaster";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    // ═══ Keybindings ═══
    public static KeyBinding openGuiKey;
    public static KeyBinding zoomKey;
    public static KeyBinding toggleSprintKey;
    public static KeyBinding toggleSneakKey;
    public static KeyBinding hitboxKey;
    public static KeyBinding fullbrightKey;
    public static KeyBinding sessionStatsKey;

    // ═══ Core Systems ═══
    public static PvPConfig config;
    public static FpsBoostManager fpsBoostManager;
    public static PvPHudRenderer hudRenderer;
    public static SessionStats sessionStats;

    // ═══ Feature Modules ═══
    public static AutoSprintFeature autoSprint;
    public static WTapFeature wTap;
    public static AntiEffectFeature antiEffect;
    public static ZoomFeature zoom;
    public static FullbrightFeature fullbright;
    public static HitEffectFeature hitEffect;
    public static ComboCounterFeature comboCounter;
    public static CpsCounterFeature cpsCounter;
    public static KillAuraFeature killAura;
    public static AutoRespawnFeature autoRespawn;
    public static TimeChangerFeature timeChanger;
    public static SprintInWaterFeature sprintInWater;
    public static LowHpAlertFeature lowHpAlert;
    public static AttackCooldownFeature attackCooldown;
    public static NoSprintParticlesFeature noSprintParticles;
    public static ItemSwitcherFeature itemSwitcher;

    @Override
    public void onInitializeClient() {
        LOGGER.info("╔══════════════════════════════════════╗");
        LOGGER.info("║   PvPMaster v3.0.0 - 90 Features    ║");
        LOGGER.info("║   Minecraft 1.21.1 | Fabric          ║");
        LOGGER.info("╚══════════════════════════════════════╝");

        // Load config first
        config = PvPConfig.load();

        // Register keybindings
        registerKeybindings();

        // Init core systems
        fpsBoostManager = new FpsBoostManager();
        hudRenderer = new PvPHudRenderer();
        sessionStats = new SessionStats();

        // Init feature modules
        autoSprint = new AutoSprintFeature();
        wTap = new WTapFeature();
        antiEffect = new AntiEffectFeature();
        zoom = new ZoomFeature();
        fullbright = new FullbrightFeature();
        hitEffect = new HitEffectFeature();
        comboCounter = new ComboCounterFeature();
        cpsCounter = new CpsCounterFeature();
        killAura = new KillAuraFeature();
        autoRespawn = new AutoRespawnFeature();
        timeChanger = new TimeChangerFeature();
        sprintInWater = new SprintInWaterFeature();
        lowHpAlert = new LowHpAlertFeature();
        attackCooldown = new AttackCooldownFeature();
        noSprintParticles = new NoSprintParticlesFeature();
        itemSwitcher = new ItemSwitcherFeature();

        // Main tick loop
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player == null) return;

            handleKeybindings(client);

            // Tick all features
            autoSprint.tick(client);
            wTap.tick(client);
            antiEffect.tick(client);
            zoom.tick(client);
            fullbright.tick(client);
            hitEffect.tick(client);
            comboCounter.tick(client);
            cpsCounter.tick(client);
            killAura.tick(client);
            autoRespawn.tick(client);
            timeChanger.tick(client);
            sprintInWater.tick(client);
            lowHpAlert.tick(client);
            attackCooldown.tick(client);
            noSprintParticles.tick(client);
            itemSwitcher.tick(client);
            fpsBoostManager.tick(client);
            sessionStats.tick(client);

            // [77] AutoGG
            sessionStats.checkAutoGG(client);
        });

        // HUD render
        HudRenderCallback.EVENT.register((drawContext, renderTickCounter) -> {
            hudRenderer.render(drawContext, renderTickCounter.getTickDelta(true));
        });

        LOGGER.info("║  90 Features Loaded Successfully!   ║");
        LOGGER.info("║  Press RIGHT SHIFT for settings!    ║");
    }

    private void registerKeybindings() {
        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.pvpmaster.opengui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.pvpmaster"));
        zoomKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.pvpmaster.zoom", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, "category.pvpmaster"));
        toggleSprintKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.pvpmaster.togglesprint", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_V, "category.pvpmaster"));
        toggleSneakKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.pvpmaster.togglesneak", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_X, "category.pvpmaster"));
        hitboxKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.pvpmaster.hitbox", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_B, "category.pvpmaster"));
        fullbrightKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.pvpmaster.fullbright", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_N, "category.pvpmaster"));
        sessionStatsKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.pvpmaster.stats", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_M, "category.pvpmaster"));
    }

    private void handleKeybindings(net.minecraft.client.MinecraftClient client) {
        while (openGuiKey.wasPressed()) {
            client.setScreen(new com.pvpmaster.gui.PvPMasterScreen());
        }
        while (toggleSprintKey.wasPressed()) {
            config.toggleSprint = !config.toggleSprint;
            config.save();
        }
        while (toggleSneakKey.wasPressed()) {
            config.toggleSneak = !config.toggleSneak;
            config.save();
        }
        while (hitboxKey.wasPressed()) {
            config.hitboxDisplay = !config.hitboxDisplay;
            config.save();
        }
        while (fullbrightKey.wasPressed()) {
            config.fullBright = !config.fullBright;
            config.save();
        }
        while (sessionStatsKey.wasPressed()) {
            // Toggle session stats display
            sessionStats.toggleDisplay();
        }
    }
}
