package com.pvpmaster.gui;

import com.pvpmaster.PvPMasterMod;
import com.pvpmaster.PvPConfig;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;
import java.lang.reflect.Field;

/**
 * PvPMaster Settings GUI
 * Press RIGHT SHIFT in-game to open!
 * 6 Tabs: HUD | PvP | FPS | Visual | Utility | Info
 */
public class PvPMasterScreen extends Screen {

    private int tab = 0;
    private final String[] tabNames = {"§6HUD", "§cPvP", "§aFPS", "§bVisual", "§dUtility", "§eInfo"};

    // Features per tab: {fieldName, displayName}
    private final String[][][] tabFeatures = {
        // [0] HUD
        {
            {"invHUD",         "§f[1]  InvHUD - Show Inventory"},
            {"armorHUD",       "§f[2]  Armor HUD"},
            {"potionHUD",      "§f[3]  Potion HUD"},
            {"fpsCounter",     "§f[4]  FPS Counter"},
            {"pingDisplay",    "§f[5]  Ping Display"},
            {"cpsCounter",     "§f[6]  CPS Counter"},
            {"keystrokesHUD",  "§f[7]  Keystrokes HUD (WASD)"},
            {"reachDisplay",   "§f[8]  Reach Display"},
            {"directionHUD",   "§f[9]  Direction / Compass HUD"},
            {"speedometer",    "§f[10] Speedometer"},
            {"healthDisplay",  "§f[11] Custom Health Display"},
            {"coordinatesHUD", "§f[12] Coordinates HUD (XYZ)"},
            {"clockHUD",       "§f[13] Clock HUD"},
            {"comboCounter",   "§f[14] Combo Counter"},
            {"chunkDisplay",   "§f[15] Chunk Display"},
            {"saturationHUD",  "§f[16] Saturation HUD"},
            {"arrowCounter",   "§f[17] Arrow Counter"},
            {"itemInfoHUD",    "§f[18] Item Durability HUD"},
        },
        // [1] PvP
        {
            {"autoSprint",         "§f[19] Auto Sprint"},
            {"sprintReset",        "§f[20] Sprint Reset (W-Tap)"},
            {"toggleSprint",       "§f[21] Toggle Sprint [V]"},
            {"toggleSneak",        "§f[22] Toggle Sneak [X]"},
            {"hitIndicator",       "§f[23] Hit Indicator"},
            {"noHurtCam",          "§f[24] No Hurt Camera"},
            {"hitSound",           "§f[25] Custom Hit Sound"},
            {"killEffect",         "§f[26] Kill Effect"},
            {"blockHitSound",      "§f[27] Block Hit Sound"},
            {"antiBlindness",      "§f[28] Anti Blindness"},
            {"antiNausea",         "§f[29] Anti Nausea"},
            {"noPunchDelay",       "§f[30] No Punch Delay"},
            {"clickSounds",        "§f[31] Click Sounds"},
            {"swordBlock",         "§f[32] Old Sword Block"},
            {"antiFireDamage",     "§f[33] Anti Fire Visual"},
            {"noSprintParticles",  "§f[34] No Sprint Particles"},
            {"attackCooldownBar",  "§f[35] Attack Cooldown Bar"},
            {"lowHpAlert",         "§f[36] Low HP Alert"},
            {"killAura",           "§4[37] Kill Aura (Careful!)"},
            {"reachExtender",      "§f[38] Reach Display Ext"},
            {"autoGAppleAlert",    "§f[39] Auto GApple Alert"},
            {"hitBlocker",         "§f[40] Hit Blocker"},
        },
        // [2] FPS Boost
        {
            {"particleLimiter",   "§f[41] Particle Limiter"},
            {"entityCulling",     "§f[42] Entity Culling"},
            {"disableFog",        "§f[43] Fog Disabler §a+8FPS"},
            {"disableSky",        "§f[44] Sky Disabler §a+5FPS"},
            {"chunkOptimizer",    "§f[45] Chunk Optimizer §a+20FPS"},
            {"gcOptimizer",       "§f[46] GC Optimizer"},
            {"renderDistOpt",     "§f[47] Auto Render Distance"},
            {"shadowRemover",     "§f[48] Shadow Remover §a+15FPS"},
            {"weatherReducer",    "§f[49] Weather Reducer"},
            {"entityLimiter",     "§f[50] Entity Limiter §a+30FPS"},
            {"chunkBorderHide",   "§f[51] Hide Chunk Borders"},
            {"fastMath",          "§f[52] Fast Math"},
            {"cacheTextures",     "§f[53] Texture Cache"},
            {"reduceAnimations",  "§f[54] Reduce Animations"},
            {"lowDetailMode",     "§c[55] LOW DETAIL MODE §4(Ultra Boost)"},
        },
        // [3] Visual
        {
            {"customCrosshair",    "§f[56] Custom Crosshair"},
            {"chromaItems",        "§f[57] Chroma Items"},
            {"enchantGlintRemove", "§f[58] No Enchant Glint"},
            {"cleanHUD",           "§f[59] Clean HUD Mode"},
            {"oldAnimations",      "§f[60] Old 1.8 Animations"},
            {"armAnimator",        "§f[61] Smooth Arm Animator"},
            {"zoomFeature",        "§f[62] Zoom [C key]"},
            {"fullBright",         "§f[63] Full Bright [N key]"},
            {"nametagThroughWall", "§f[64] Nametag Through Walls"},
            {"customFOV",          "§f[65] Custom FOV"},
            {"damageTiltRemove",   "§f[66] No Damage Tilt"},
            {"bobRemoval",         "§f[67] Remove View Bob"},
            {"fireHeightReduce",   "§f[68] Lower Fire Overlay"},
            {"itemPhysics",        "§f[69] Item Physics"},
            {"customSkyColor",     "§f[70] Custom Sky Color"},
            {"customHitColor",     "§f[71] Custom Hit Color"},
            {"chromaHUDText",      "§f[72] Chroma HUD Text"},
            {"noPotionShift",      "§f[73] No Potion HUD Shift"},
            {"noPumpkinOverlay",   "§f[74] No Pumpkin Overlay"},
            {"cleanDebugScreen",   "§f[75] Clean F3 Debug Screen"},
        },
        // [4] Utility
        {
            {"screenshotAnnounce", "§f[76] Screenshot Announce"},
            {"autoGG",             "§f[77] Auto GG"},
            {"autoRespawn",        "§f[78] Auto Respawn"},
            {"fpsLimiter",         "§f[79] FPS Limiter"},
            {"memoryDisplay",      "§f[80] Memory Display"},
            {"dayCounter",         "§f[81] Day Counter"},
            {"chatFilter",         "§f[82] Chat Filter"},
            {"timeChanger",        "§f[83] Time Changer"},
            {"weatherChanger",     "§f[84] Weather Changer"},
            {"hitboxDisplay",      "§f[85] Hitbox Display [B key]"},
            {"blockOverlay",       "§f[86] Block Target Overlay"},
            {"sprintInWater",      "§f[87] Sprint In Water"},
            {"noFallDamageCam",    "§f[88] No Fall Damage Cam"},
            {"itemSwitcher",       "§f[89] Smart Item Switcher"},
            {"sessionStats",       "§f[90] Session Stats [M key]"},
        },
        // [5] Info - no toggles, just display
        {}
    };

    public PvPMasterScreen() {
        super(Text.literal("PvPMaster"));
    }

    @Override
    protected void init() {
        // Tab buttons
        for (int i = 0; i < tabNames.length; i++) {
            final int t = i;
            addDrawableChild(ButtonWidget.builder(Text.literal(tabNames[i]),
                btn -> { tab = t; clearAndInit(); })
                .dimensions(5 + i * 55, 20, 53, 16).build());
        }

        if (tab == 5) return; // Info tab - no buttons

        String[][] features = tabFeatures[tab];
        int cols = 2;
        int colW = (this.width - 20) / cols;
        for (int i = 0; i < features.length; i++) {
            final String field = features[i][0];
            final String label = features[i][1];
            int col = i % cols;
            int row = i / cols;
            boolean val = getBool(field);
            addDrawableChild(ButtonWidget.builder(
                Text.literal(val ? "§a✔ " + label : "§c✘ " + label),
                btn -> {
                    toggleBool(field);
                    boolean nv = getBool(field);
                    btn.setMessage(Text.literal(nv ? "§a✔ " + label : "§c✘ " + label));
                    PvPMasterMod.config.save();
                }
            ).dimensions(5 + col * colW, 42 + row * 18, colW - 5, 16).build());
        }

        // Reset & Close
        addDrawableChild(ButtonWidget.builder(Text.literal("§cReset"), btn -> {
            PvPMasterMod.config = new PvPConfig();
            PvPMasterMod.config.save();
            clearAndInit();
        }).dimensions(this.width - 110, this.height - 22, 50, 16).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("§7Close"), btn -> close())
            .dimensions(this.width - 58, this.height - 22, 53, 16).build());
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        renderBackground(ctx, mx, my, delta);

        // Header gradient
        ctx.fillGradient(0, 0, this.width, 18, 0xFF1a1a2e, 0xFF16213e);
        ctx.drawCenteredTextWithShadow(textRenderer,
            Text.literal("§6§l⚔ PvPMaster §8| §7v3.0.0 §8| §f90 Features §8| §aMC 1.21.1"),
            this.width / 2, 4, 0xFFFFFF);

        // Active tab highlight
        ctx.fill(5 + tab * 55, 19, 5 + tab * 55 + 53, 36, 0x44FFAA00);

        // Tab content divider
        ctx.fill(0, 38, this.width, 39, 0xFF333333);

        if (tab == 5) renderInfoTab(ctx);

        super.render(ctx, mx, my, delta);

        // Bottom bar
        ctx.fillGradient(0, this.height - 26, this.width, this.height, 0xFF111111, 0xFF000000);
        ctx.drawTextWithShadow(textRenderer,
            Text.literal("§7Loaded: §a90§7 features | §7Keys: §eRSHIFT§7=GUI §eC§7=Zoom §eV§7=Sprint §eX§7=Sneak §eB§7=Hitbox §eN§7=Bright §eM§7=Stats"),
            5, this.height - 18, 0x888888);
    }

    private void renderInfoTab(DrawContext ctx) {
        int x = 10, y = 50;
        ctx.drawTextWithShadow(textRenderer, Text.literal("§6§lPvPMaster v3.0.0 - Feature Summary"), x, y, 0xFFAA00);
        ctx.drawTextWithShadow(textRenderer, Text.literal("§7HUD Features:    §f18  §7features"), x, y + 14, 0xFFFFFF);
        ctx.drawTextWithShadow(textRenderer, Text.literal("§7PvP/Combat:      §f22  §7features"), x, y + 26, 0xFFFFFF);
        ctx.drawTextWithShadow(textRenderer, Text.literal("§7FPS Boost:       §f15  §7features"), x, y + 38, 0xFFFFFF);
        ctx.drawTextWithShadow(textRenderer, Text.literal("§7Visual:          §f20  §7features"), x, y + 50, 0xFFFFFF);
        ctx.drawTextWithShadow(textRenderer, Text.literal("§7Utility:         §f15  §7features"), x, y + 62, 0xFFFFFF);
        ctx.drawTextWithShadow(textRenderer, Text.literal("§6Total:           §a90  §6features"), x, y + 78, 0xFFAA00);
        ctx.drawTextWithShadow(textRenderer, Text.literal("§7Minecraft:       §f1.21.1 Fabric"), x, y + 96, 0xFFFFFF);
        ctx.drawTextWithShadow(textRenderer, Text.literal("§7FPS Boost:       §aUp to +100 FPS"), x, y + 108, 0xFFFFFF);
        ctx.drawTextWithShadow(textRenderer, Text.literal("§cKillAura is disabled by default - use on practice servers only!"), x, y + 130, 0xFF5555);
    }

    private boolean getBool(String field) {
        try { return (boolean) PvPConfig.class.getField(field).get(PvPMasterMod.config); }
        catch (Exception e) { return false; }
    }

    private void toggleBool(String field) {
        try {
            Field f = PvPConfig.class.getField(field);
            f.set(PvPMasterMod.config, !(boolean) f.get(PvPMasterMod.config));
        } catch (Exception ignored) {}
    }

    @Override public boolean shouldPause() { return false; }
}
