package com.pvpmaster.hud;

import com.pvpmaster.PvPMasterMod;
import com.pvpmaster.PvPConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.Direction;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Collection;

/**
 * PvPMaster HUD Renderer - All 18 HUD Elements
 * Renders on-screen with configurable positions and styles.
 */
public class PvPHudRenderer {

    private final MinecraftClient mc = MinecraftClient.getInstance();
    private float chromaHue = 0f;
    private boolean wDown, aDown, sDown, dDown, lmbDown, rmbDown;
    private int lastPing = 0, pingTimer = 0;

    public void render(DrawContext ctx, float tickDelta) {
        if (mc.player == null || mc.getDebugHud().shouldShowDebugHud()) return;

        PvPConfig cfg = PvPMasterMod.config;
        TextRenderer tr = mc.textRenderer;
        ClientPlayerEntity player = mc.player;
        int sw = mc.getWindow().getScaledWidth();
        int sh = mc.getWindow().getScaledHeight();

        chromaHue = (chromaHue + 0.008f) % 1.0f;
        updateKeystrokes();

        // ─── [1] InvHUD ───
        if (cfg.invHUD) renderInvHUD(ctx, cfg.invHudX, cfg.invHudY, player);

        // ─── [2] ArmorHUD ───
        if (cfg.armorHUD) renderArmorHUD(ctx, tr, cfg.armorHudX, cfg.armorHudY, player);

        // ─── [3] PotionHUD ───
        if (cfg.potionHUD) renderPotionHUD(ctx, tr, sw - 125, cfg.potionHudY, player);

        // ─── [4] FPS Counter ───
        if (cfg.fpsCounter) {
            int fps = mc.getCurrentFps();
            int fpsColor = fps >= 60 ? 0x55FF55 : fps >= 30 ? 0xFFAA00 : 0xFF5555;
            String t = fps + " FPS";
            renderHudText(ctx, tr, t, sw - tr.getWidth(t) - 3, 3, fpsColor, cfg);
        }

        // ─── [5] Ping Display ───
        if (cfg.pingDisplay && mc.getNetworkHandler() != null) {
            pingTimer++;
            if (pingTimer > 20) {
                pingTimer = 0;
                var entry = mc.getNetworkHandler().getPlayerListEntry(player.getUuid());
                if (entry != null) lastPing = entry.getLatency();
            }
            int col = lastPing < 50 ? 0x55FF55 : lastPing < 100 ? 0xFFFF55 : 0xFF5555;
            String t = lastPing + "ms";
            renderHudText(ctx, tr, t, sw - tr.getWidth(t) - 3, cfg.fpsCounter ? 14 : 3, col, cfg);
        }

        // ─── [6] CPS Counter ───
        if (cfg.cpsCounter) renderCpsHUD(ctx, tr, cfg.cpsX, cfg.cpsY, cfg);

        // ─── [7] Keystrokes HUD ───
        if (cfg.keystrokesHUD) renderKeystrokes(ctx, tr, cfg.keystrokesX, cfg.keystrokesY);

        // ─── [8] Reach Display ───
        if (cfg.reachDisplay) renderHudText(ctx, tr, "Reach: 3.0", 3, sh - 90, 0xFFFFFF, cfg);

        // ─── [9] Direction HUD ───
        if (cfg.directionHUD) renderDirectionHUD(ctx, tr, sw / 2, 4, player);

        // ─── [10] Speedometer ───
        if (cfg.speedometer) {
            double sp = Math.sqrt(player.getVelocity().x * player.getVelocity().x + player.getVelocity().z * player.getVelocity().z);
            renderHudText(ctx, tr, String.format("%.2f b/s", sp * 20), 3, sh - 55, 0xAAAAAA, cfg);
        }

        // ─── [11] Health Display ───
        if (cfg.healthDisplay) {
            float hp = player.getHealth(), maxHp = player.getMaxHealth();
            int hc = hp > maxHp * 0.6f ? 0xFF5555 : hp > maxHp * 0.3f ? 0xFFAA00 : 0xFF0000;
            String t = String.format("❤ %.1f / %.0f", hp, maxHp);
            renderHudText(ctx, tr, t, sw / 2 - tr.getWidth(t) / 2, sh - 45, hc, cfg);
        }

        // ─── [12] Coordinates ───
        if (cfg.coordinatesHUD) {
            String t = String.format("X:%.0f Y:%.0f Z:%.0f", player.getX(), player.getY(), player.getZ());
            renderHudText(ctx, tr, t, 3, sh - 22, 0xAAAAAA, cfg);
        }

        // ─── [13] Clock HUD ───
        if (cfg.clockHUD) {
            String t = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"));
            renderHudText(ctx, tr, t, sw - tr.getWidth(t) - 3, sh - 22, 0xCCCCCC, cfg);
        }

        // ─── [14] Combo Counter ───
        if (cfg.comboCounter) {
            int combo = PvPMasterMod.comboCounter.getCombo();
            if (combo > 1) {
                String t = combo + "x COMBO!";
                int cc = cfg.chromaHUDText ? getChromaColor() : 0xFFAA00;
                renderHudText(ctx, tr, t, sw / 2 - tr.getWidth(t) / 2, sh / 2 - 70, cc, cfg);
            }
        }

        // ─── [15] Chunk Display ───
        if (cfg.chunkDisplay) {
            int cx = (int) player.getX() >> 4, cz = (int) player.getZ() >> 4;
            renderHudText(ctx, tr, "Chunk: " + cx + ", " + cz, 3, sh - 33, 0x888888, cfg);
        }

        // ─── [16] Saturation HUD ───
        if (cfg.saturationHUD) {
            float sat = player.getHungerManager().getSaturationLevel();
            String t = String.format("Sat: %.1f", sat);
            renderHudText(ctx, tr, t, 3, sh - 65, 0xFFDD55, cfg);
        }

        // ─── [17] Arrow Counter ───
        if (cfg.arrowCounter) {
            int arrows = 0;
            for (int i = 0; i < player.getInventory().size(); i++) {
                ItemStack s = player.getInventory().getStack(i);
                if (s.isOf(net.minecraft.item.Items.ARROW) || s.isOf(net.minecraft.item.Items.TIPPED_ARROW)
                        || s.isOf(net.minecraft.item.Items.SPECTRAL_ARROW)) {
                    arrows += s.getCount();
                }
            }
            if (arrows > 0) renderHudText(ctx, tr, "🏹 " + arrows, sw - 40, sh - 55, 0xFFFFAA, cfg);
        }

        // ─── [18] Item Info HUD ───
        if (cfg.itemInfoHUD) {
            ItemStack held = player.getMainHandStack();
            if (!held.isEmpty() && held.isDamageable()) {
                int dur = held.getMaxDamage() - held.getDamage();
                int maxDur = held.getMaxDamage();
                int pc = (int)((float)dur / maxDur * 100);
                int ic = pc > 50 ? 0x55FF55 : pc > 20 ? 0xFFAA00 : 0xFF5555;
                String t = dur + "/" + maxDur + " (" + pc + "%)";
                renderHudText(ctx, tr, t, sw / 2 - tr.getWidth(t) / 2, sh - 60, ic, cfg);
            }
        }

        // ─── [35] Attack Cooldown Bar ───
        if (cfg.attackCooldownBar) renderAttackCooldownBar(ctx, sw, sh, player, cfg);

        // ─── [80] Memory Display ───
        if (cfg.memoryDisplay) {
            long used = (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) / 1048576L;
            long total = Runtime.getRuntime().maxMemory() / 1048576L;
            String t = used + "MB / " + total + "MB";
            int mc2 = used > total * 0.8 ? 0xFF5555 : used > total * 0.5 ? 0xFFAA00 : 0x55FF55;
            renderHudText(ctx, tr, t, sw - tr.getWidth(t) - 3, sh - 10, mc2, cfg);
        }

        // ─── [85] Hitbox Display ───
        if (cfg.hitboxDisplay) {
            renderHudText(ctx, tr, "§cHitboxes ON", 3, 3, 0xFF5555, cfg);
        }

        // ─── [90] Session Stats ───
        if (cfg.sessionStats && PvPMasterMod.sessionStats.isDisplaying()) {
            renderSessionStats(ctx, tr, sw, sh);
        }
    }

    // ═══════════════════════════════════════════════════
    //  HUD ELEMENT RENDERERS
    // ═══════════════════════════════════════════════════

    private void renderHudText(DrawContext ctx, TextRenderer tr, String text, int x, int y, int color, PvPConfig cfg) {
        if (cfg.hudBackground) {
            ctx.fill(x - 1, y - 1, x + tr.getWidth(text) + 1, y + 9, 0x88000000);
        }
        int finalColor = cfg.chromaHUDText ? getChromaColor() : color;
        ctx.drawTextWithShadow(tr, text, x, y, finalColor);
    }

    /** [1] InvHUD - Full inventory rendered on screen */
    private void renderInvHUD(DrawContext ctx, int x, int y, ClientPlayerEntity player) {
        // Semi-transparent background
        ctx.fill(x - 3, y - 55, x + 168, y + 22, 0xAA000000);
        ctx.fill(x - 2, y - 54, x + 167, y + 21, 0x33FFFFFF);

        // Inventory rows (slots 9-35)
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                int slot = 9 + row * 9 + col;
                ItemStack stack = player.getInventory().getStack(slot);
                int rx = x + col * 18;
                int ry = y - 54 + row * 18;
                ctx.drawItem(stack, rx, ry);
                ctx.drawItemInSlot(mc.textRenderer, stack, rx, ry);
            }
        }

        // Hotbar (slots 0-8)
        for (int i = 0; i < 9; i++) {
            ItemStack stack = player.getInventory().getStack(i);
            // Highlight selected slot
            if (i == player.getInventory().selectedSlot) {
                ctx.fill(x + i * 18 - 1, y + 2, x + i * 18 + 17, y + 20, 0x55FFFFFF);
            }
            ctx.drawItem(stack, x + i * 18, y + 3);
            ctx.drawItemInSlot(mc.textRenderer, stack, x + i * 18, y + 3);
        }

        // Offhand
        ItemStack offhand = player.getOffHandStack();
        if (!offhand.isEmpty()) {
            ctx.drawItem(offhand, x + 168, y + 3);
            ctx.drawItemInSlot(mc.textRenderer, offhand, x + 168, y + 3);
        }
    }

    /** [2] ArmorHUD */
    private void renderArmorHUD(DrawContext ctx, TextRenderer tr, int x, int y, ClientPlayerEntity player) {
        ctx.fill(x - 2, y - 2, x + 80, y + 54, 0x88000000);
        ctx.drawTextWithShadow(tr, "Armor", x, y, 0xCCCCCC);

        String[] slots = {"Helm", "Chst", "Legs", "Boot"};
        int[] invSlots = {39, 38, 37, 36};

        for (int i = 0; i < 4; i++) {
            ItemStack armor = player.getInventory().getStack(invSlots[i]);
            if (!armor.isEmpty()) {
                int durability = armor.getMaxDamage() - armor.getDamage();
                int maxDur = armor.getMaxDamage();
                int pct = maxDur > 0 ? (int)((float)durability / maxDur * 100) : 100;
                int color = pct > 50 ? 0x55FF55 : pct > 20 ? 0xFFAA00 : 0xFF5555;
                ctx.drawItem(armor, x, y + 10 + i * 11);
                ctx.drawTextWithShadow(tr, slots[i] + ": " + pct + "%", x + 18, y + 12 + i * 11, color);
            } else {
                ctx.drawTextWithShadow(tr, slots[i] + ": --", x + 18, y + 12 + i * 11, 0x555555);
            }
        }
    }

    /** [3] PotionHUD */
    private void renderPotionHUD(DrawContext ctx, TextRenderer tr, int x, int y, ClientPlayerEntity player) {
        Collection<StatusEffectInstance> effects = player.getStatusEffects();
        if (effects.isEmpty()) return;
        int i = 0;
        for (StatusEffectInstance effect : effects) {
            String name = effect.getEffectType().value().getName().getString();
            if (name.length() > 13) name = name.substring(0, 13);
            int dur = effect.getDuration() / 20;
            String time = dur > 60 ? (dur / 60) + "m" + (dur % 60) + "s" : dur + "s";
            String line = name + " " + (effect.getAmplifier() > 0 ? "II " : "") + time;
            int col = effect.getEffectType().value().getColor() | 0xFF000000;
            ctx.fill(x - 1, y + i * 13 - 1, x + 120, y + i * 13 + 10, 0x88000000);
            ctx.drawTextWithShadow(tr, line, x, y + i * 13, col);
            i++;
            if (i > 10) break;
        }
    }

    /** [6] CPS HUD */
    private void renderCpsHUD(DrawContext ctx, TextRenderer tr, int x, int y, PvPConfig cfg) {
        int cps = PvPMasterMod.cpsCounter.getCPS();
        String t = "CPS: " + cps;
        int col = cps >= 12 ? 0xFF55FF : cps >= 8 ? 0x55FF55 : cps >= 4 ? 0xFFAA00 : 0xAAAAAA;
        renderHudText(ctx, tr, t, x, y, col, cfg);
    }

    /** [7] Keystrokes HUD */
    private void renderKeystrokes(DrawContext ctx, TextRenderer tr, int x, int y) {
        drawKey(ctx, tr, "W", x + 14, y, wDown);
        drawKey(ctx, tr, "A", x, y + 13, aDown);
        drawKey(ctx, tr, "S", x + 14, y + 13, sDown);
        drawKey(ctx, tr, "D", x + 28, y + 13, dDown);
        drawWideKey(ctx, tr, "LMB", x, y + 27, lmbDown, 0xFF4444FF);
        drawWideKey(ctx, tr, "RMB", x + 21, y + 27, rmbDown, 0xFF4444FF);
    }

    private void drawKey(DrawContext ctx, TextRenderer tr, String label, int x, int y, boolean pressed) {
        int bg = pressed ? 0xFF55FF55 : 0xFF333333;
        ctx.fill(x, y, x + 13, y + 12, 0xFF000000);
        ctx.fill(x + 1, y + 1, x + 12, y + 11, bg);
        ctx.drawCenteredTextWithShadow(tr, label, x + 6, y + 2, pressed ? 0xFF000000 : 0xFFAAAAAA);
    }

    private void drawWideKey(DrawContext ctx, TextRenderer tr, String label, int x, int y, boolean pressed, int activeColor) {
        int bg = pressed ? activeColor : 0xFF333333;
        ctx.fill(x, y, x + 19, y + 10, 0xFF000000);
        ctx.fill(x + 1, y + 1, x + 18, y + 9, bg);
        ctx.drawCenteredTextWithShadow(tr, label, x + 9, y + 1, pressed ? 0xFFFFFFFF : 0xFFAAAAAA);
    }

    /** [9] Direction / Compass HUD */
    private void renderDirectionHUD(DrawContext ctx, TextRenderer tr, int cx, int y, ClientPlayerEntity player) {
        float yaw = player.getYaw() % 360;
        if (yaw < 0) yaw += 360;
        String dir = switch (player.getHorizontalFacing()) {
            case NORTH -> "§cN";
            case SOUTH -> "§aS";
            case EAST -> "§9E";
            case WEST -> "§6W";
            default -> "?";
        };
        String t = "< " + dir + " §f" + (int) yaw + "° >";
        ctx.fill(cx - 55, y - 1, cx + 55, y + 10, 0x88000000);
        ctx.drawCenteredTextWithShadow(tr, t, cx, y, 0xFFFFFF);
    }

    /** [35] Attack Cooldown Bar */
    private void renderAttackCooldownBar(DrawContext ctx, int sw, int sh, ClientPlayerEntity player, PvPConfig cfg) {
        float cooldown = player.getAttackCooldownProgress(0f);
        if (cooldown >= 1.0f) return;
        int barW = 80;
        int bx = sw / 2 - barW / 2;
        int by = sh / 2 + 15;
        ctx.fill(bx - 1, by - 1, bx + barW + 1, by + 5, 0xFF000000);
        ctx.fill(bx, by, bx + (int)(barW * cooldown), by + 4, cfg.attackCooldownBarColor);
    }

    /** [90] Session Stats panel */
    private void renderSessionStats(DrawContext ctx, TextRenderer tr, int sw, int sh) {
        var stats = PvPMasterMod.sessionStats;
        int x = sw - 110, y = 30;
        ctx.fill(x - 3, y - 3, x + 105, y + 70, 0xAA000000);
        ctx.drawTextWithShadow(tr, "§6§lSession Stats", x, y, 0xFFAA00);
        ctx.drawTextWithShadow(tr, "§fKills: §a" + stats.getKills(), x, y + 12, 0xFFFFFF);
        ctx.drawTextWithShadow(tr, "§fDeaths: §c" + stats.getDeaths(), x, y + 24, 0xFFFFFF);
        String kd = stats.getDeaths() > 0 ? String.format("%.2f", (float) stats.getKills() / stats.getDeaths()) : "∞";
        ctx.drawTextWithShadow(tr, "§fK/D: §e" + kd, x, y + 36, 0xFFFFFF);
        ctx.drawTextWithShadow(tr, "§fStreak: §b" + stats.getStreak(), x, y + 48, 0xFFFFFF);
        ctx.drawTextWithShadow(tr, "§fBest Streak: §d" + stats.getBestStreak(), x, y + 60, 0xFFFFFF);
    }

    private void updateKeystrokes() {
        if (mc.options == null) return;
        wDown = mc.options.forwardKey.isPressed();
        aDown = mc.options.leftKey.isPressed();
        sDown = mc.options.backKey.isPressed();
        dDown = mc.options.rightKey.isPressed();
        lmbDown = mc.options.attackKey.isPressed();
        rmbDown = mc.options.useKey.isPressed();
    }

    public int getChromaColor() {
        float r = Math.abs((float) Math.sin(chromaHue * (float) Math.PI));
        float g = Math.abs((float) Math.sin((chromaHue + 0.33f) * (float) Math.PI));
        float b = Math.abs((float) Math.sin((chromaHue + 0.66f) * (float) Math.PI));
        return 0xFF000000 | ((int)(r * 255) << 16) | ((int)(g * 255) << 8) | (int)(b * 255);
    }
}
