package com.pvpmaster.fps;

import com.pvpmaster.PvPMasterMod;
import net.minecraft.client.MinecraftClient;

/**
 * FPS Boost Manager - Features [41-55]
 * All FPS optimizations managed here
 */
public class FpsBoostManager {
    private int gcTimer = 0, lastFps = 60;

    public void tick(MinecraftClient mc) {
        if (mc.world == null) return;
        PvPMasterMod.PvPConfig cfg = null;
        try { cfg = PvPMasterMod.config; } catch (Exception e) { return; }

        // [46] GC Optimizer
        if (cfg.gcOptimizer && (++gcTimer >= 600 || (lastFps - mc.getCurrentFps() > 25 && gcTimer > 100))) {
            gcTimer = 0;
            System.gc();
        }
        lastFps = mc.getCurrentFps();

        // [47] Auto Render Distance
        if (cfg.renderDistOpt && mc.player != null) {
            int fps = mc.getCurrentFps(), dist = mc.options.getViewDistance().getValue();
            if (fps < 30 && dist > 4) mc.options.getViewDistance().setValue(dist - 1);
            else if (fps > 80 && dist < 12) mc.options.getViewDistance().setValue(dist + 1);
        }

        // [54] Reduce Animations - disable entity animations when far
        if (cfg.reduceAnimations && mc.player != null) {
            // handled via entity renderer mixin
        }

        // [55] Low Detail Mode - super fps boost
        if (cfg.lowDetailMode) {
            if (mc.options.getViewDistance().getValue() > 4) mc.options.getViewDistance().setValue(4);
            if (mc.options.getEntityDistanceScaling().getValue() > 0.5) mc.options.getEntityDistanceScaling().setValue(0.5);
        }
    }

    public static boolean shouldDisableFog() { return PvPMasterMod.config.disableFog; }
    public static boolean shouldRemoveShadows() { return PvPMasterMod.config.shadowRemover; }
    public static int getMaxParticles() { return PvPMasterMod.config.particleLimiter ? PvPMasterMod.config.maxParticles : 16384; }
    public static boolean shouldReduceWeather() { return PvPMasterMod.config.weatherReducer; }
    public static boolean shouldCullEntity() { return PvPMasterMod.config.entityCulling; }
    public static int getMaxEntities() { return PvPMasterMod.config.maxEntities; }
}

// Workaround for inner class reference
class PvPMasterModRef {
    static com.pvpmaster.PvPConfig getConfig() { return PvPMasterMod.config; }
}
