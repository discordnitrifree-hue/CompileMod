package com.pvpmaster.features;
import com.pvpmaster.PvPMasterMod;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

/** [36] Low HP Alert - Warns when health is critical */
public class LowHpAlertFeature {
    private boolean wasLow = false;
    public void tick(MinecraftClient mc) {
        if (mc.player == null || !PvPMasterMod.config.lowHpAlert) return;
        boolean isLow = mc.player.getHealth() <= PvPMasterMod.config.lowHpThreshold;
        if (isLow && !wasLow) {
            mc.player.sendMessage(Text.literal("§c§l⚠ LOW HP! ⚠ §r§cHealth: " +
                String.format("%.1f", mc.player.getHealth())), true);
        }
        wasLow = isLow;
    }
}
