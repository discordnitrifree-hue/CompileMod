package com.pvpmaster.features;
import com.pvpmaster.PvPMasterMod;
import net.minecraft.client.MinecraftClient;

/** [63] Full Bright - Maximum gamma */
public class FullbrightFeature {
    private float originalGamma = -1f;
    public void tick(MinecraftClient mc) {
        if (!PvPMasterMod.config.fullBright) {
            if (originalGamma >= 0) { mc.options.getGamma().setValue((double)originalGamma); originalGamma = -1f; }
            return;
        }
        if (originalGamma < 0) originalGamma = (float)(double)mc.options.getGamma().getValue();
        if ((double)mc.options.getGamma().getValue() < 15.0) mc.options.getGamma().setValue(15.0);
    }
}
