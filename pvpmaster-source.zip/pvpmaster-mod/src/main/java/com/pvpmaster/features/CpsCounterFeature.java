package com.pvpmaster.features;
import net.minecraft.client.MinecraftClient;
import java.util.ArrayDeque;
import java.util.Deque;

/** [6] CPS Counter */
public class CpsCounterFeature {
    private final Deque<Long> clicks = new ArrayDeque<>();
    private boolean wasPressed = false;
    public void tick(MinecraftClient mc) {
        if (mc.options == null) return;
        boolean pressed = mc.options.attackKey.isPressed();
        if (pressed && !wasPressed) onClick();
        wasPressed = pressed;
        prune();
    }
    public void onClick() { clicks.addLast(System.currentTimeMillis()); prune(); }
    private void prune() {
        long now = System.currentTimeMillis();
        while (!clicks.isEmpty() && now - clicks.peekFirst() > 1000) clicks.pollFirst();
    }
    public int getCPS() { prune(); return clicks.size(); }
}
