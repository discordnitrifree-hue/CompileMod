package com.pvpmaster.features;
import com.pvpmaster.PvPMasterMod;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.DeathScreen;

/** [78] Auto Respawn - Instantly clicks respawn button */
public class AutoRespawnFeature {
    public void tick(MinecraftClient mc) {
        if (!PvPMasterMod.config.autoRespawn) return;
        if (mc.currentScreen instanceof DeathScreen) {
            mc.player.requestRespawn();
            mc.setScreen(null);
        }
    }
}
