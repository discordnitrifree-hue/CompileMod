package com.pvpmaster.features;
import com.pvpmaster.PvPMasterMod;
import net.minecraft.client.MinecraftClient;

/** [83] Time Changer - Client-side time change (visual only) */
public class TimeChangerFeature {
    public void tick(MinecraftClient mc) {
        if (!PvPMasterMod.config.timeChanger || mc.world == null) return;
        // Note: actual time change requires server permission. This sets visual client time.
        // mc.world.setTime(PvPMasterMod.config.timeChangerValue);
        // Disabled by default - enable on servers where allowed
    }
}
