package com.pvpmaster.features;
import com.pvpmaster.PvPMasterMod;
import net.minecraft.client.MinecraftClient;

/** [34] No Sprint Particles - removes running particles */
public class NoSprintParticlesFeature {
    public void tick(MinecraftClient mc) { /* handled via ParticleManagerMixin */ }
}
