package com.pvpmaster.features;
import com.pvpmaster.PvPMasterMod;
import net.minecraft.client.MinecraftClient;

/** [35] Attack Cooldown - tracked for HUD bar rendering */
public class AttackCooldownFeature {
    public void tick(MinecraftClient mc) { /* cooldown bar rendered in HUD */ }
}
