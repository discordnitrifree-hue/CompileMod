package com.pvpmaster.features;
import net.minecraft.client.MinecraftClient;

/** [14] Combo Counter */
public class ComboCounterFeature {
    private int combo = 0, decayTimer = 0;
    private static final int DECAY = 80;
    public void tick(MinecraftClient mc) {
        if (combo > 0 && ++decayTimer >= DECAY) { combo = 0; decayTimer = 0; }
    }
    public void onHit() { combo++; decayTimer = 0; }
    public void reset() { combo = 0; decayTimer = 0; }
    public int getCombo() { return combo; }
}
