package com.pvpmaster.features;
import com.pvpmaster.PvPMasterMod;
import net.minecraft.client.MinecraftClient;

/** [23] Hit Effect */
public class HitEffectFeature {
    public void tick(MinecraftClient mc) {}
    public void onHit() { /* triggered from mixin */ }
    public void onKill() { /* kill effect triggered from mixin */ }
}
