package com.pvpmaster.features;
import com.pvpmaster.PvPMasterMod;
import net.minecraft.client.MinecraftClient;

/** [87] Sprint In Water */
public class SprintInWaterFeature {
    public void tick(MinecraftClient mc) {
        if (mc.player == null || !PvPMasterMod.config.sprintInWater) return;
        if (mc.player.isSubmergedInWater() && mc.options.forwardKey.isPressed()) {
            mc.player.setSprinting(true);
        }
    }
}
