package com.pvpmaster.features;
import com.pvpmaster.PvPMasterMod;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.effect.StatusEffects;

/** [28][29] Anti Blindness & Anti Nausea */
public class AntiEffectFeature {
    public void tick(MinecraftClient mc) {
        if (mc.player == null) return;
        if (PvPMasterMod.config.antiBlindness) mc.player.removeStatusEffect(StatusEffects.BLINDNESS);
        if (PvPMasterMod.config.antiNausea) mc.player.removeStatusEffect(StatusEffects.NAUSEA);
    }
}
