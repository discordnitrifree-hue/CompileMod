package com.pvpmaster.features;
import com.pvpmaster.PvPMasterMod;
import net.minecraft.client.MinecraftClient;

/** [62] Zoom - OptiFine-style zoom with smooth transition */
public class ZoomFeature {
    private float originalFov = -1f;
    private boolean wasZooming = false;
    public void tick(MinecraftClient mc) {
        if (mc.player == null || !PvPMasterMod.config.zoomFeature) return;
        boolean zooming = PvPMasterMod.zoomKey.isPressed();
        if (zooming && !wasZooming) originalFov = mc.options.getFov().getValue();
        if (zooming) {
            float target = originalFov / PvPMasterMod.config.zoomLevel;
            float cur = mc.options.getFov().getValue();
            mc.options.getFov().setValue((int)(cur + (target - cur) * 0.35f));
        } else if (wasZooming && originalFov > 0) {
            mc.options.getFov().setValue((int) originalFov);
            originalFov = -1f;
        }
        wasZooming = zooming;
    }
}
