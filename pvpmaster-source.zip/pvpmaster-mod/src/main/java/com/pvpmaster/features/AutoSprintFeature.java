package com.pvpmaster.features;

import com.pvpmaster.PvPMasterMod;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.effect.StatusEffects;

/** [19] Auto Sprint */
public class AutoSprintFeature {
    public void tick(MinecraftClient mc) {
        if (!PvPMasterMod.config.autoSprint || mc.player == null) return;
        if (mc.options.forwardKey.isPressed() && !mc.player.isSprinting()
                && !mc.player.isSneaking() && mc.player.getHungerManager().getFoodLevel() > 6) {
            mc.player.setSprinting(true);
        }
    }
}
