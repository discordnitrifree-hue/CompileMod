package com.pvpmaster.features;
import com.pvpmaster.PvPMasterMod;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;

/**
 * [37] Kill Aura - Attacks nearest hostile entity
 * NOTE: Disable on legit servers! For private/practice use only.
 */
public class KillAuraFeature {
    private int attackTimer = 0;
    public void tick(MinecraftClient mc) {
        if (mc.player == null || !PvPMasterMod.config.killAura) return;
        if (++attackTimer < 10) return; // attack every 10 ticks
        attackTimer = 0;
        float range = PvPMasterMod.config.killAuraRange;
        LivingEntity target = null;
        double closestDist = range * range;
        for (var entity : mc.world.getEntities()) {
            if (!(entity instanceof LivingEntity living)) continue;
            if (entity == mc.player) continue;
            if (entity instanceof PlayerEntity) continue; // only mobs
            double dist = mc.player.squaredDistanceTo(entity);
            if (dist < closestDist) { closestDist = dist; target = living; }
        }
        if (target != null) mc.interactionManager.attackEntity(mc.player, target);
    }
}
