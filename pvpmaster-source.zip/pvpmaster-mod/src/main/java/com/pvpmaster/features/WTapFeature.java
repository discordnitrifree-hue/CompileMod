package com.pvpmaster.features;
import com.pvpmaster.PvPMasterMod;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.effect.StatusEffects;

/** [20] Sprint Reset / W-Tap */
public class WTapFeature {
    private boolean wasAttacking = false;
    private int resetTimer = 0;
    public void tick(MinecraftClient mc) {
        if (mc.player == null || !PvPMasterMod.config.sprintReset) return;
        boolean attacking = mc.options.attackKey.isPressed();
        if (attacking && !wasAttacking && mc.player.isSprinting()) {
            mc.player.setSprinting(false);
            resetTimer = 3;
        }
        if (resetTimer > 0 && --resetTimer == 0 && mc.options.forwardKey.isPressed())
            mc.player.setSprinting(true);
        wasAttacking = attacking;
    }
}
