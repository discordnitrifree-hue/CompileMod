package com.pvpmaster;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.*;
import java.nio.file.Path;

/**
 * ╔══════════════════════════════════════════════════════════╗
 * ║           PvPMaster v3.0.0 - Config                     ║
 * ║         90 Features | Minecraft 1.21.1 Fabric            ║
 * ╚══════════════════════════════════════════════════════════╝
 *
 * ALL 90 FEATURES:
 *
 * ══ HUD FEATURES (1-18) ══
 *  [1]  InvHUD              - Inventory on screen
 *  [2]  ArmorHUD            - Armor durability
 *  [3]  PotionHUD           - Active potion effects
 *  [4]  FPS Counter         - Real-time FPS
 *  [5]  Ping Display        - Server latency
 *  [6]  CPS Counter         - Clicks per second
 *  [7]  Keystrokes HUD      - WASD + Mouse display
 *  [8]  Reach Display       - Attack reach
 *  [9]  Direction HUD       - Compass
 *  [10] Speedometer         - Movement speed
 *  [11] Health Display      - Custom HP numbers
 *  [12] Coordinates HUD     - XYZ position
 *  [13] Clock HUD           - Real time
 *  [14] Combo Counter       - Kill/hit combo
 *  [15] Chunk Display       - Chunk info
 *  [16] Saturation HUD      - Food saturation
 *  [17] Arrow Counter       - Arrows in inventory
 *  [18] Item Info HUD       - Held item durability
 *
 * ══ PvP / COMBAT FEATURES (19-40) ══
 *  [19] AutoSprint          - Always sprint
 *  [20] Sprint Reset (W-Tap)- Auto knockback boost
 *  [21] ToggleSprint        - Toggle sprint [V]
 *  [22] ToggleSneak         - Toggle sneak [X]
 *  [23] Hit Indicator       - Screen flash on hit
 *  [24] NoHurtCam           - No camera shake
 *  [25] Hit Sound           - Custom hit sound
 *  [26] Kill Effect         - Visual on kill
 *  [27] Block Hit Sound     - Sound on block
 *  [28] Anti Blindness      - Remove blindness
 *  [29] Anti Nausea         - Remove nausea
 *  [30] No Punch Delay      - Faster attack
 *  [31] Click Sounds        - Click sound on click
 *  [32] Old Sword Block     - Re-enable sword block
 *  [33] Anti Fire Damage    - Visual only
 *  [34] Sprint Particles    - Remove sprint particles
 *  [35] Attack Cooldown Bar - Custom cooldown bar
 *  [36] Low HP Alert        - Warning at low health
 *  [37] KillAura (Target)   - Attack nearest enemy
 *  [38] Reach Extender      - Slightly longer reach
 *  [39] Auto GApple         - Alert on gap available
 *  [40] Hit Blocker         - Prevent misclicks
 *
 * ══ FPS BOOST FEATURES (41-55) ══
 *  [41] Particle Limiter    - Reduce particles
 *  [42] Entity Culling      - Skip hidden entities
 *  [43] Fog Disabler        - Remove fog
 *  [44] Sky Disabler        - No sky render
 *  [45] Chunk Optimizer     - Better chunks
 *  [46] GC Optimizer        - Reduce GC pauses
 *  [47] Auto Render Dist    - Dynamic distance
 *  [48] Shadow Remover      - No entity shadows
 *  [49] Weather Reducer     - Less rain
 *  [50] Entity Limiter      - Max visible entities
 *  [51] Chunk Border Hide   - No chunk borders
 *  [52] Fast Math           - Optimized math ops
 *  [53] Cache Textures      - Better tex cache
 *  [54] Reduce Animations   - Less entity animations
 *  [55] Low Detail Mode     - Ultra FPS mode
 *
 * ══ VISUAL FEATURES (56-75) ══
 *  [56] Custom Crosshair    - 6 styles
 *  [57] Chroma Items        - Rainbow items
 *  [58] No Enchant Glint    - Remove glint
 *  [59] Clean HUD           - Minimal mode
 *  [60] Old Animations      - 1.8 style
 *  [61] Arm Animator        - Smooth swing
 *  [62] Zoom [C]            - Optifine zoom
 *  [63] Full Bright         - Max brightness
 *  [64] Nametag Through Wall- See names
 *  [65] Custom FOV          - FOV control
 *  [66] No Damage Tilt      - No screen tilt
 *  [67] Remove View Bob     - No bobbing
 *  [68] Fire Height Reduce  - Lower fire overlay
 *  [69] Item Physics        - Dropped item spin
 *  [70] Custom Sky Color    - Change sky color
 *  [71] Hit Color           - Custom hurt color
 *  [72] Chroma HUD          - Rainbow HUD text
 *  [73] No Potion Shift     - No HUD shift on potion
 *  [74] No Pumpkin Overlay  - Remove pumpkin blur
 *  [75] Clean Debug Screen  - Nicer F3 menu
 *
 * ══ UTILITY FEATURES (76-90) ══
 *  [76] Screenshot Announce - Auto announce screenshot
 *  [77] AutoGG              - Auto say GG on win
 *  [78] Auto RespawnFast    - Instant respawn click
 *  [79] FPS Limiter         - Max FPS cap
 *  [80] Memory Display      - RAM usage shown
 *  [81] Day Counter         - Minecraft days
 *  [82] Chat Filter         - Filter bad words
 *  [83] Time Changer        - Client-side time
 *  [84] Weather Changer     - Client-side weather
 *  [85] Hitbox Display      - Show entity hitboxes
 *  [86] Block Overlay       - Block target highlight
 *  [87] Sprint In Water     - Sprint while swimming
 *  [88] No Fall Damage Cam  - No cam on fall
 *  [89] Item Switcher       - Quick slot switch
 *  [90] Session Stats       - Kill/death tracker
 */
public class PvPConfig {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_PATH = FabricLoader.getInstance()
            .getConfigDir().resolve("pvpmaster.json");

    // ═══════════════════════════════════════════
    //  HUD FEATURES [1-18]
    // ═══════════════════════════════════════════
    public boolean invHUD = true;
    public boolean armorHUD = true;
    public boolean potionHUD = true;
    public boolean fpsCounter = true;
    public boolean pingDisplay = true;
    public boolean cpsCounter = true;
    public boolean keystrokesHUD = true;
    public boolean reachDisplay = false;
    public boolean directionHUD = true;
    public boolean speedometer = false;
    public boolean healthDisplay = true;
    public boolean coordinatesHUD = false;
    public boolean clockHUD = false;
    public boolean comboCounter = true;
    public boolean chunkDisplay = false;
    public boolean saturationHUD = false;
    public boolean arrowCounter = true;
    public boolean itemInfoHUD = true;

    // HUD Positions
    public int invHudX = 2, invHudY = 60;
    public int armorHudX = 2, armorHudY = 110;
    public int keystrokesX = 2, keystrokesY = 150;
    public int cpsX = 2, cpsY = 210;
    public int potionHudX = 5, potionHudY = 30;

    // HUD style
    public boolean chromaHUD = false;
    public int hudTextColor = 0xFFFFFF;
    public boolean hudBackground = true;
    public int hudBackgroundAlpha = 0x88;

    // ═══════════════════════════════════════════
    //  PvP / COMBAT FEATURES [19-40]
    // ═══════════════════════════════════════════
    public boolean autoSprint = true;
    public boolean sprintReset = true;
    public boolean toggleSprint = false;
    public boolean toggleSneak = false;
    public boolean hitIndicator = true;
    public boolean noHurtCam = true;
    public boolean hitSound = true;
    public boolean killEffect = true;
    public boolean blockHitSound = false;
    public boolean antiBlindness = true;
    public boolean antiNausea = true;
    public boolean noPunchDelay = true;
    public boolean clickSounds = false;
    public boolean swordBlock = false;
    public boolean antiFireDamage = false;
    public boolean noSprintParticles = true;
    public boolean attackCooldownBar = true;
    public boolean lowHpAlert = true;
    public boolean killAura = false;          // [37] Use with caution on legit servers
    public boolean reachExtender = false;     // [38] Cosmetic only
    public boolean autoGAppleAlert = true;
    public boolean hitBlocker = false;

    // Combat settings
    public float hitColor_R = 1.0f, hitColor_G = 0.0f, hitColor_B = 0.0f, hitColor_A = 0.5f;
    public float lowHpThreshold = 6.0f;
    public String hitSoundId = "entity.player.attack.strong";
    public float hitSoundVolume = 1.0f;
    public float hitSoundPitch = 1.5f;
    public int attackCooldownBarColor = 0xFF55FF55;
    public float killAuraRange = 3.5f;

    // ═══════════════════════════════════════════
    //  FPS BOOST FEATURES [41-55]
    // ═══════════════════════════════════════════
    public boolean particleLimiter = true;
    public boolean entityCulling = true;
    public boolean disableFog = true;
    public boolean disableSky = false;
    public boolean chunkOptimizer = true;
    public boolean gcOptimizer = true;
    public boolean renderDistOpt = false;
    public boolean shadowRemover = true;
    public boolean weatherReducer = true;
    public boolean entityLimiter = true;
    public boolean chunkBorderHide = true;
    public boolean fastMath = true;
    public boolean cacheTextures = true;
    public boolean reduceAnimations = true;
    public boolean lowDetailMode = false;

    // FPS settings
    public int maxParticles = 50;
    public int maxEntities = 50;
    public int fpsLimitValue = 0; // 0 = unlimited

    // ═══════════════════════════════════════════
    //  VISUAL FEATURES [56-75]
    // ═══════════════════════════════════════════
    public boolean customCrosshair = true;
    public boolean chromaItems = false;
    public boolean enchantGlintRemove = true;
    public boolean cleanHUD = false;
    public boolean oldAnimations = true;
    public boolean armAnimator = true;
    public boolean zoomFeature = true;
    public boolean fullBright = true;
    public boolean nametagThroughWall = true;
    public boolean customFOV = false;
    public boolean damageTiltRemove = true;
    public boolean bobRemoval = true;
    public boolean fireHeightReduce = true;
    public boolean itemPhysics = false;
    public boolean customSkyColor = false;
    public boolean customHitColor = true;
    public boolean chromaHUDText = false;
    public boolean noPotionShift = true;
    public boolean noPumpkinOverlay = true;
    public boolean cleanDebugScreen = false;

    // Visual settings
    public int crosshairStyle = 0;           // 0=plus 1=dot 2=X 3=circle 4=gap 5=dynamic
    public int crosshairColor = 0xFFFFFFFF;
    public int crosshairSize = 5;
    public float zoomLevel = 4.0f;
    public float customFovValue = 90.0f;
    public int customSkyR = 135, customSkyG = 206, customSkyB = 235;
    public float chromaSpeed = 1.0f;

    // ═══════════════════════════════════════════
    //  UTILITY FEATURES [76-90]
    // ═══════════════════════════════════════════
    public boolean screenshotAnnounce = false;
    public boolean autoGG = false;
    public boolean autoRespawn = true;
    public boolean fpsLimiter = false;
    public boolean memoryDisplay = true;
    public boolean dayCounter = false;
    public boolean chatFilter = false;
    public boolean timeChanger = false;
    public boolean weatherChanger = false;
    public boolean hitboxDisplay = false;
    public boolean blockOverlay = false;
    public boolean sprintInWater = true;
    public boolean noFallDamageCam = true;
    public boolean itemSwitcher = false;
    public boolean sessionStats = true;

    // Utility settings
    public int clientTime = 6000;            // for timeChanger
    public String autoGGMessage = "GG!";
    public String autoGGLoseMessage = "GG, nice game!";
    public int timeChangerValue = 6000;      // 0=midnight 6000=noon
    public boolean clientWeatherClear = true;

    // ═══════════════════════════════════════════
    //  SAVE / LOAD
    // ═══════════════════════════════════════════
    public static PvPConfig load() {
        try {
            if (CONFIG_PATH.toFile().exists()) {
                try (Reader reader = new FileReader(CONFIG_PATH.toFile())) {
                    PvPConfig cfg = GSON.fromJson(reader, PvPConfig.class);
                    if (cfg != null) return cfg;
                }
            }
        } catch (Exception e) {
            PvPMasterMod.LOGGER.warn("Config load failed, using defaults: " + e.getMessage());
        }
        return new PvPConfig();
    }

    public void save() {
        try {
            CONFIG_PATH.getParent().toFile().mkdirs();
            try (Writer writer = new FileWriter(CONFIG_PATH.toFile())) {
                GSON.toJson(this, writer);
            }
        } catch (Exception e) {
            PvPMasterMod.LOGGER.error("Config save failed: " + e.getMessage());
        }
    }
}
