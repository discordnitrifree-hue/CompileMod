package com.pvpmaster.mixin;

import com.pvpmaster.fps.FpsBoostManager;
import com.pvpmaster.PvPMasterMod;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * [48] Shadow Remover
 * [64] Nametag Through Walls - Fixed for 1.21.1
 */
@Mixin(EntityRenderer.class)
public class EntityRendererMixin<T extends Entity> {

    @Inject(method = "getShadowRadius", at = @At("HEAD"), cancellable = true)
    private void removeShadow(T entity, CallbackInfoReturnable<Float> cir) {
        if (FpsBoostManager.shouldRemoveShadows()) cir.setReturnValue(0f);
    }

    // Fixed: 1.21.1 me hasLabel signature change hua - boolean parameter hata diya
    @Inject(method = "hasLabel(Lnet/minecraft/entity/Entity;)Z",
            at = @At("RETURN"), cancellable = true)
    private void nametagThroughWall(T entity, CallbackInfoReturnable<Boolean> cir) {
        if (PvPMasterMod.config.nametagThroughWall && entity instanceof PlayerEntity) {
            cir.setReturnValue(true);
        }
    }
}
