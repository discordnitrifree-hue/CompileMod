package com.pvpmaster.mixin;

import com.pvpmaster.PvPMasterMod;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * [56] Custom Crosshair
 * [73] No Potion HUD Shift
 * Fixed for 1.21.1
 */
@Mixin(InGameHud.class)
public class InGameHudMixin {

    @Inject(method = "renderCrosshair",
            at = @At("HEAD"), cancellable = true, require = 0)
    private void customCrosshair(DrawContext ctx, RenderTickCounter tickCounter, CallbackInfo ci) {
        if (!PvPMasterMod.config.customCrosshair) return;
        ci.cancel();

        int cx = ctx.getScaledWindowWidth() / 2;
        int cy = ctx.getScaledWindowHeight() / 2;
        int color = PvPMasterMod.config.crosshairColor;
        int size = PvPMasterMod.config.crosshairSize;

        switch (PvPMasterMod.config.crosshairStyle) {
            case 0 -> { // Plus
                ctx.fill(cx - size, cy - 1, cx + size + 1, cy + 1, color);
                ctx.fill(cx - 1, cy - size, cx + 1, cy + size + 1, color);
            }
            case 1 -> ctx.fill(cx - 2, cy - 2, cx + 2, cy + 2, color); // Dot
            case 2 -> { // X
                for (int i = -size; i <= size; i++) {
                    ctx.fill(cx + i, cy + i, cx + i + 1, cy + i + 1, color);
                    ctx.fill(cx + i, cy - i, cx + i + 1, cy - i + 1, color);
                }
            }
            case 3 -> { // Gap
                int gap = 4;
                ctx.fill(cx - size - gap, cy - 1, cx - gap, cy + 1, color);
                ctx.fill(cx + gap, cy - 1, cx + size + gap + 1, cy + 1, color);
                ctx.fill(cx - 1, cy - size - gap, cx + 1, cy - gap, color);
                ctx.fill(cx - 1, cy + gap, cx + 1, cy + size + gap + 1, color);
            }
            case 4 -> { // Circle
                for (int angle = 0; angle < 360; angle += 12) {
                    int x = cx + (int)(size * 1.5 * Math.cos(Math.toRadians(angle)));
                    int y = cy + (int)(size * 1.5 * Math.sin(Math.toRadians(angle)));
                    ctx.fill(x, y, x + 1, y + 1, color);
                }
            }
        }
    }

    @Inject(method = "renderStatusEffectOverlay",
            at = @At("HEAD"), cancellable = true, require = 0)
    private void noPotionShift(DrawContext ctx, float posX, float posY, CallbackInfo ci) {
        if (PvPMasterMod.config.noPotionShift) ci.cancel();
    }
}
