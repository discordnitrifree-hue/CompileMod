package com.pvpmaster.mixin;

import com.pvpmaster.PvPMasterMod;
import net.minecraft.client.Mouse;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Mouse Mixin
 * [62] Zoom scroll sensitivity reduction while zoomed
 */
@Mixin(Mouse.class)
public class MouseMixin {

    @Inject(method = "onMouseScroll", at = @At("HEAD"), cancellable = true)
    private void zoomScroll(long window, double horizontal, double vertical, CallbackInfo ci) {
        if (PvPMasterMod.config.zoomFeature && PvPMasterMod.zoomKey.isPressed()) {
            // Adjust zoom level with scroll
            PvPMasterMod.config.zoomLevel = Math.max(1.5f,
                Math.min(10f, PvPMasterMod.config.zoomLevel - (float)(vertical * 0.5)));
            ci.cancel();
        }
    }
}
