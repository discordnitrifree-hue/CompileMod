package com.pvpmaster.mixin;

import com.pvpmaster.fps.FpsBoostManager;
import net.minecraft.client.render.BackgroundRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.FogType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * BackgroundRenderer Mixin
 * [43] Fog Disabler - massive FPS boost
 */
@Mixin(BackgroundRenderer.class)
public class BackgroundRendererMixin {

    @Inject(method = "applyFog", at = @At("HEAD"), cancellable = true)
    private static void disableFog(Camera camera, FogType fogType, float viewDistance,
                                    boolean thickFog, float tickDelta, CallbackInfo ci) {
        if (FpsBoostManager.shouldDisableFog()) ci.cancel();
    }
}
