package com.pvpmaster.mixin;

import com.pvpmaster.PvPMasterMod;
import net.minecraft.client.render.item.ItemRenderer;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * ItemRenderer Mixin
 * [58] No Enchant Glint - remove enchantment shimmer
 */
@Mixin(ItemRenderer.class)
public class ItemRendererMixin {

    @Inject(method = "renderGlint", at = @At("HEAD"), cancellable = true)
    private static void noEnchantGlint(CallbackInfo ci) {
        if (PvPMasterMod.config.enchantGlintRemove) ci.cancel();
    }
}
