package com.pvpmaster.mixin;

import com.pvpmaster.PvPMasterMod;
import net.minecraft.client.render.item.ItemRenderer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.model.BakedModel;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * [58] No Enchant Glint - Fixed for 1.21.1
 */
@Mixin(ItemRenderer.class)
public class ItemRendererMixin {

    // Fixed: renderGlint method signature updated for 1.21.1
    @Inject(
        method = "renderGlint(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;IILnet/minecraft/client/render/model/BakedModel;)V",
        at = @At("HEAD"),
        cancellable = true,
        require = 0  // require=0 means won't crash if method not found
    )
    private static void noEnchantGlint(MatrixStack matrices,
                                        VertexConsumerProvider vertexConsumers,
                                        int light, int overlay,
                                        BakedModel model,
                                        CallbackInfo ci) {
        if (PvPMasterMod.config.enchantGlintRemove) ci.cancel();
    }
}
