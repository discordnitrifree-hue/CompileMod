package com.pvpmaster.mixin;

import com.pvpmaster.PvPMasterMod;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * ClientPlayerEntity Mixin
 * [22] Toggle Sneak
 * [67] Remove View Bob (via game options sync)
 */
@Mixin(ClientPlayerEntity.class)
public class ClientPlayerEntityMixin {

    @Inject(method = "tick", at = @At("TAIL"))
    private void onTick(CallbackInfo ci) {
        ClientPlayerEntity player = (ClientPlayerEntity)(Object)this;
        var cfg = PvPMasterMod.config;
        if (cfg == null) return;

        // [22] Toggle Sneak
        if (cfg.toggleSneak) player.setSneaking(true);

        // [67] Bob Removal - sync game option
        if (cfg.bobRemoval && net.minecraft.client.MinecraftClient.getInstance().options.getBobView().getValue()) {
            net.minecraft.client.MinecraftClient.getInstance().options.getBobView().setValue(false);
        }

        // [74] No Pumpkin Overlay
        if (cfg.noPumpkinOverlay && !player.getInventory().getArmorStack(3).isEmpty()
                && player.getInventory().getArmorStack(3).isOf(net.minecraft.item.Items.CARVED_PUMPKIN)) {
            // Pumpkin is in helmet slot - overlay suppressed via rendering mixin
        }
    }
}
