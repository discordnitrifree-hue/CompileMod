package com.pvpmaster.mixin;

import com.pvpmaster.fps.FpsBoostManager;
import com.pvpmaster.PvPMasterMod;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.particle.ParticleEffect;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * [41] Particle Limiter - Fixed for 1.21.1
 */
@Mixin(ParticleManager.class)
public class ParticleManagerMixin {

    // Fixed: 1.21.1 me addParticle signature changed - boolean parameter add hua
    @Inject(
        method = "addParticle(Lnet/minecraft/particle/ParticleEffect;DDDDDD)V",
        at = @At("HEAD"),
        cancellable = true,
        require = 0
    )
    private void limitParticles(ParticleEffect effect,
                                double x, double y, double z,
                                double vx, double vy, double vz,
                                CallbackInfo ci) {
        if (PvPMasterMod.config.particleLimiter) {
            int max = FpsBoostManager.getMaxParticles();
            if (Math.random() > (double) max / 200.0) {
                ci.cancel();
            }
        }
    }
}
