package com.pvpmaster.mixin;

import com.pvpmaster.fps.FpsBoostManager;
import com.pvpmaster.PvPMasterMod;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.particle.ParticleEffect;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Queue;

/**
 * ParticleManager Mixin
 * [41] Particle Limiter
 * [34] No Sprint Particles
 */
@Mixin(ParticleManager.class)
public class ParticleManagerMixin {

    @Inject(method = "addParticle(Lnet/minecraft/particle/ParticleEffect;DDDDDD)V",
            at = @At("HEAD"), cancellable = true)
    private void limitParticles(ParticleEffect effect, double x, double y, double z,
                                double vx, double vy, double vz, CallbackInfo ci) {
        // [41] Particle limiter
        if (PvPMasterMod.config.particleLimiter) {
            // Simple rate limiter using hash to allow ~maxParticles
            int max = FpsBoostManager.getMaxParticles();
            if (Math.random() > (double) max / 200.0) {
                ci.cancel();
                return;
            }
        }
    }
}
