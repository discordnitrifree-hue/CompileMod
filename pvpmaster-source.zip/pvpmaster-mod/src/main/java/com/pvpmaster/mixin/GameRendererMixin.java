package com.pvpmaster.mixin;

import com.pvpmaster.PvPMasterMod;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * GameRenderer Mixin
 * [24] NoHurtCam - [66] No Damage Tilt
 */
@Mixin(GameRenderer.class)
public class GameRendererMixin {

    @Inject(method = "bobViewWhenHurt", at = @At("HEAD"), cancellable = true)
    private void noHurtCam(MatrixStack matrices, float tickDelta, CallbackInfo ci) {
        if (PvPMasterMod.config.noHurtCam) ci.cancel();
    }

    @Inject(method = "tiltViewWhenHurt", at = @At("HEAD"), cancellable = true)
    private void noDamageTilt(MatrixStack matrices, float tickDelta, CallbackInfo ci) {
        if (PvPMasterMod.config.damageTiltRemove) ci.cancel();
    }
}
