package com.pvpmaster.util;

import com.pvpmaster.PvPMasterMod;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

/**
 * [90] Session Stats Tracker
 * Tracks kills, deaths, K/D ratio and streaks per session
 */
public class SessionStats {
    private int kills = 0, deaths = 0, streak = 0, bestStreak = 0;
    private boolean displaying = true;
    private float lastHealth = 20f;

    public void tick(MinecraftClient mc) {
        if (mc.player == null) return;
        float currentHealth = mc.player.getHealth();
        // Detect death (health drops to 0)
        if (lastHealth > 0 && currentHealth <= 0) {
            deaths++;
            streak = 0;
        }
        lastHealth = currentHealth;
    }

    public void onKill() {
        kills++;
        streak++;
        if (streak > bestStreak) bestStreak = streak;
    }

    public void checkAutoGG(MinecraftClient mc) {
        if (!PvPMasterMod.config.autoGG || mc.player == null) return;
        // Auto GG is triggered externally when kill/death is detected
    }

    public void sendAutoGG(MinecraftClient mc, boolean won) {
        if (!PvPMasterMod.config.autoGG || mc.getNetworkHandler() == null) return;
        String msg = won ? PvPMasterMod.config.autoGGMessage : PvPMasterMod.config.autoGGLoseMessage;
        mc.getNetworkHandler().sendChatMessage(msg);
    }

    public void toggleDisplay() { displaying = !displaying; }
    public boolean isDisplaying() { return displaying; }
    public int getKills() { return kills; }
    public int getDeaths() { return deaths; }
    public int getStreak() { return streak; }
    public int getBestStreak() { return bestStreak; }
    public void reset() { kills = 0; deaths = 0; streak = 0; bestStreak = 0; }
}
